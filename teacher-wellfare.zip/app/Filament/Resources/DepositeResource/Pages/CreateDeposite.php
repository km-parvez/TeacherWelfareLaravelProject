<?php

namespace App\Filament\Resources\DepositeResource\Pages;

use App\Filament\Resources\DepositeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDeposite extends CreateRecord
{
    protected static string $resource = DepositeResource::class;
}
