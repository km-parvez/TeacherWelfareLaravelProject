<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $districts = App\Models\District::with('subDistricts')->get();
    ?>
<div class="bg-white rounded-lg w-1/2 px-4 py-4">
    <form action="<?php echo e(route('report')); ?>" method="POST" class="px-4">
        <?php echo csrf_field(); ?>
        <div class="flex justify-between py-5 items-center">
    <label for="district">District:</label>
    <select id="district" name="district" class="rounded-lg">
        <option value="">Select District</option>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($district->id); ?>"><?php echo e($district->e_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </select>
</div>
<div class="flex justify-between  items-center py-5">
    <label for="subdistrict">Subdistrict:</label>
    <select id="subdistrict" name="subdistrict" class="rounded-lg">
        <option value="">Select Upazila</option>
    </select>
</div>
<div class="flex justify-between  items-center py-5">
    
     <input type="hidden" value="3" name="reporttype">
</div>
<div class="flex justify-end">
<button class="fi-btn relative grid-flow-col items-center justify-center font-semibold outline-none transition duration-75 focus-visible:ring-2 rounded-lg fi-color-custom fi-btn-color-primary fi-size-md fi-btn-size-md gap-1.5 px-3 py-2 text-sm inline-grid shadow-sm bg-blue-500 text-white hover:bg-custom-500 dark:bg-custom-500 dark:hover:bg-custom-400 focus-visible:ring-custom-500/50 dark:focus-visible:ring-custom-400/50 fi-ac-btn-action" style="background-color: #2563eb">Submit</button></div>
</form>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get references to the district and subdistrict select elements
        var districtSelect = document.getElementById('district');
        var subdistrictSelect = document.getElementById('subdistrict');

        // Add an event listener to the district select element
        districtSelect.addEventListener('change', function () {
            // Clear existing subdistrict options
            subdistrictSelect.innerHTML = '<option value="">Select Subdistrict</option>';

            // Get the selected district ID
            var selectedDistrictId = districtSelect.value;

            // If a district is selected, fetch and populate subdistrict options
            if (selectedDistrictId) {
                // Replace the URL with your actual route to fetch subdistricts
                var url = '/get-subdistricts/' + selectedDistrictId;

                // Fetch subdistricts using AJAX
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        // Populate subdistrict options
                        data.forEach(subdistrict => {
                            var option = document.createElement('option');
                            option.value = subdistrict.id;
                            option.text = subdistrict.e_name;
                            subdistrictSelect.add(option);
                        });
                    })
                    .catch(error => console.error('Error:', error));
            }
        });
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH D:\Laravel\teacher-wellfare\resources\views/filament/pages/grant.blade.php ENDPATH**/ ?>